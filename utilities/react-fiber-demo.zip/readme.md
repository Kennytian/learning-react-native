了解 React Fiber 


https://segmentfault.com/a/1190000009075692#articleHeader13
http://www.infoq.com/cn/articles/what-the-new-engine-of-react
https://www.zhihu.com/question/49496872?sort=created
https://zhuanlan.zhihu.com/p/26027085
https://www.zhihu.com/lives/896398188230103040/audition-messages
